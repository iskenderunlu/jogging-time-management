(function (){
  var app = angular.module('Jogging.accounts',
                          ['Jogging.accounts.ctrl',
                           'Jogging.accounts.service']);
})();
