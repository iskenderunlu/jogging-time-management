(function (){
  var app = angular.module('Jogging.timings',
                          ['Jogging.timings.ctrl',
                           'Jogging.timings.service']);
})();
