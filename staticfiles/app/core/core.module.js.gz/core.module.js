(function (){
  var app = angular.module('Jogging.core',
                          ['Jogging.core.ctrl',
                           'Jogging.core.service']);
})();
